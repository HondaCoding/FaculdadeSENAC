<?php
/*
class Index{

    public function __construct(){

    }
}
*/

if(isset($_POST["opcao"]) && !empty($_POST["opcao"])){

        if($_POST["opcao"] == "inserir"){
            include("../model/Produto.php");
            $conn = new Produto();//model
            if(isset($_POST["IDProduto"]) && isset($_POST["NomeProduto"]) && isset($_POST["Estado"]) && isset($_POST["SiglaUF"]) && isset($_POST["Cidade"]) && !empty($_POST["IDProduto"]) && !empty($_POST["NomeProduto"]) && !empty($_POST["Estado"]) && !empty($_POST["SiglaUF"]) && !empty($_POST["Cidade"])){
                
                $inserir = $conn->addProduto($_POST["IDProduto"], $_POST["NomeProduto"], $_POST["Estado"], $_POST["SiglaUF"], $_POST["Cidade"]);
                           
                if($inserir) 
                    header("location: ../index.php?pagina=Produto&opcao=listAll&acao=inserir&mensagem=sucesso");
                else 
                    header("location: ../index.php?pagina=Produto&opcao=listAll&acao=inserir&mensagem=erro");
            }
        }elseif($_POST["opcao"] == "alterar"){
            include("../model/Produto.php");
            $conn = new Produto();//model
            if(isset($_POST["IDProduto"]) && isset($_POST["NomeProduto"]) 
            && isset($_POST["Estado"]) && isset($_POST["SiglaUF"]) && isset($_POST["Cidade"]) 
        && !empty($_POST["IDProduto"]) && !empty($_POST["NomeProduto"]) 
        && !empty($_POST["Estado"]) && !empty($_POST["SiglaUF"]) && !empty($_POST["Cidade"])){
                
                $update = $conn->updateProduto($_POST["IDProduto"], $_POST["NomeProduto"], $_POST["Estado"], $_POST["SiglaUF"], $_POST["Cidade"]);
                           
                if($update)
                    header("location: ../index.php?pagina=Produto&opcao=listAll&acao=editar&mensagem=sucesso");
                else
                    header("location: ../index.php?pagina=Produto&opcao=listAll&acao=editar&mensagem=erro");
       
            }
        }
    }elseif(isset($_GET["opcao"]) && !empty($_GET["opcao"])){
            if($_GET["opcao"] == "inserir"){
                include("./view/ListarProduto.php");
                $Produto = new ListarProduto();//view  
                $inserir = $Produto->cadastrarProduto();          
            }elseif($_GET["opcao"]=="listAll"){
                include("./model/Produto.php");
                $conn = new Produto();//model  
                $users = $conn->listAll();
                
                include("./view/ListarProduto.php");
                $Produto = new ListarProduto();//view  
                $Produto->ListarTodos($users);   

            }elseif(($_GET["opcao"] == "listOne") && isset($_GET["IDProduto"]) && !empty($_GET["IDProduto"])){
                include("./model/Produto.php");
                $conn = new Produto();//model  
                $user = $conn->listOne($_GET["IDProduto"]);
                //$Produto = new ListarProduto();
                include("./view/ListarProduto.php");
                $Produto = new ListarProduto();
                $Produto->ListarUm($user);
            }elseif(($_GET["opcao"] == "excluir") && isset($_GET["IDProduto"]) && !empty($_GET["IDProduto"])){
                include("./model/Produto.php");
                $conn = new Produto();//model  
                $user = $conn->delete($_GET["IDProduto"]);
                
                if($user)
                    header("location: index.php?pagina=Produto&opcao=listAll&acao=excluir&mensagem=sucesso");
                else
                    header("location: index.php?pagina=Produto&opcao=listAll&acao=excluir&mensagem=erro");
            }elseif(($_GET["opcao"] == "editar") && isset($_GET["IDProduto"]) && !empty($_GET["IDProduto"])){
                include("./model/Produto.php");
                $conn = new Produto();//model  
                $user = $conn->listOne($_GET["IDProduto"]);

                //chamar o formulario que está na view
                
                include("./view/ListarProduto.php");
                $Produto = new ListarProduto();//view  
                $editar = $Produto->alterarProduto($user);

                
            }
        }

