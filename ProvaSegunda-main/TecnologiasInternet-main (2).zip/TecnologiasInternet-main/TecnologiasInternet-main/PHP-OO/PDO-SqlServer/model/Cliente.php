<?php
class Cliente{
    public $connection;

    public function __construct()
    {
        try {
            $this->connection = new PDO("sqlsrv:Database=VendaVeiculos;server=localhost\SQLEXPRESS", "", "");
        } catch(PDOException $e) {
            echo 'Error: ' . $e->getMessage();
        }   
    } 

    public function listAll(){
        //$statement = $this->connection->prepare("SELECT * FROM clientes");
        $statement = $this->connection->prepare("SELECT * FROM clientes ORDER BY NomeCliente OFFSET 00
         ROWS FETCH NEXT 10 ROWS ONLY");
        $statement->execute();
        
        $users = $statement->fetchAll(PDO::FETCH_ASSOC);
        return $users;
    }

    public function listOne($IDCliente){
        $statement = $this->connection->prepare("
        SELECT * FROM clientes where IDCliente = :IDCliente");
        $statement->execute(array(":IDCliente"=>$IDCliente));
        
        $users = $statement->fetchAll(PDO::FETCH_ASSOC);
        return $users;
    }

    public function delete($IDCliente){
        $statement = $this->connection->prepare("
        delete from clientes where IDCliente = :IDCliente");
        $usuarioExcluido = $statement->execute(array(":IDCliente"=>$IDCliente));
        
        //$users = $statement->fetchAll(PDO::FETCH_ASSOC);
        if($usuarioExcluido)
            return true;
        else   
            return false;
    }

    public function addCliente($IDCliente, $NomeCliente, $Estado, $SiglaUF, $Cidade){
        try {
        $statement = $this->connection->prepare("
        insert into clientes (IDCliente, NomeCliente, Estado, SiglaUF, Cidade) 
        values(:IDCliente, :NomeCliente, :Estado, :SiglaUF, :Cidade)");

        $statement->execute(
            array(
                ":IDCliente" => $IDCliente,
                ":NomeCliente" => $NomeCliente,
                ":Estado" => $Estado,
                ":SiglaUF" => $SiglaUF,
                ":Cidade" => $Cidade
        )); 
        return true;
    } catch(PDOException $e) {
        echo 'Error: ' . $e->getMessage();
        return false;
    }        
    }
    public function updateCliente($IDCliente, $NomeCliente, $Estado, $SiglaUF, $Cidade){
        try {
        $statement = $this->connection->prepare("
        update clientes set
        NomeCliente = :NomeCliente, 
        Estado = :Estado, 
        SiglaUF = :SiglaUF, 
        Cidade = :Cidade 
        where IDCliente = :IDCliente");

        $statement->execute(
            array(
                ":IDCliente" => $IDCliente,
                ":NomeCliente" => $NomeCliente,
                ":Estado" => $Estado,
                ":SiglaUF" => $SiglaUF,
                ":Cidade" => $Cidade
        )); 
        return true;
    } catch(PDOException $e) {
        echo 'Error: ' . $e->getMessage();
        return false;
    }        
    }

}