<?php
class Produto {
    public $connection;

    public function __construct()
    {
        try {
            $this->connection = new PDO("sqlsrv:Database=VendaVeiculos;server=localhost\SQLEXPRESS", "", "");
            $this->connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Define o modo de erro para exceções
        } catch(PDOException $e) {
            echo 'Error: ' . $e->getMessage();
        }   
    } 

    public function listAll($offset = 0, $limit = 10) {
        $statement = $this->connection->prepare("
            SELECT * FROM Produto
            ORDER BY IDProduto
            OFFSET :offset ROWS
            FETCH NEXT :limit ROWS ONLY
        ");
        $statement->bindValue(':offset', (int)$offset, PDO::PARAM_INT);
        $statement->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
        $statement->execute();
        
        $products = $statement->fetchAll(PDO::FETCH_ASSOC);
        return $products;
    }

    public function listOne($IDProduto) {
        $statement = $this->connection->prepare("
            SELECT * FROM Produto
            WHERE IDProduto = :IDProduto
        ");
        $statement->execute(array(":IDProduto" => $IDProduto));
        
        $product = $statement->fetch(PDO::FETCH_ASSOC);
        return $product;
    }

    public function delete($IDProduto) {
        try {
            $statement = $this->connection->prepare("
                DELETE FROM Produto
                WHERE IDProduto = :IDProduto
            ");
            $success = $statement->execute(array(":IDProduto" => $IDProduto));
            return $success;
        } catch (PDOException $e) {
            echo 'Error: ' . $e->getMessage();
            return false;
        }
    }
    public function addProduto($IDProduto, $IDCategoria, $Produto, $IDSegmento, $Marca, $Preco) {
        try {
            $statement = $this->connection->prepare("
                INSERT INTO Produto (IDProduto, IDCategoria, Produto, IDSegmento, Marca, Preco)
                VALUES (:IDProduto, :IDCategoria, :Produto, :IDSegmento, :Marca, :Preco)
            ");
            $statement->execute(array(
                ":IDProduto" => $IDProduto,
                ":IDCategoria" => $IDCategoria,
                ":Produto" => $Produto,
                ":IDSegmento" => $IDSegmento,
                ":Marca" => $Marca,
                ":Preco" => $Preco
            )); 
            return true;
        } catch (PDOException $e) {
            echo 'Error: ' . $e->getMessage();
            return false;
        }        
    }
    

    public function updateProduto($IDProduto, $IDCategoria, $Estado, $IDSegmento, $Marca) {
        try {
            $statement = $this->connection->prepare("
                UPDATE Produto
                SET Produto = :Produto, Estado = :Estado, IDSegmento = :IDSegmento, Marca = :Marca
                WHERE IDProduto = :IDProduto
            ");
            $statement->execute(array(
                ":IDProduto" => $IDProduto,
                ":Produto" => $Produto,
                ":Estado" => $Estado,
                ":IDSegmento" => $IDSegmento,
                ":Marca" => $Marca
            )); 
            return true;
        } catch (PDOException $e) {
            echo 'Error: ' . $e->getMessage();
            return false;
        }        
    }
}
