<style>
    table, th, tr, td {
        padding: 10px;
        font-size: 25px;
        border-collapse: collapse;
    }
    table, th {
        width: 80%;
        border: 2px solid #FF760C;
    }
    td {
        border-bottom: 1px solid #8395a7;
        border-right: 1px solid #8395a7;
    }
    a {
        text-decoration: none;
    }
    .btn-cadastrar {
        background-color: #007bff;
        color: white;
        border: none;
        padding: 10px 20px;
        font-size: 16px;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }
    .btn-cadastrar:hover {
        background-color: #0056b3;
    }
    .alert {
        padding: 15px;
        margin: 15px 0;
        border-radius: 5px;
        color: #fff;
        font-family: Arial, sans-serif;
    }
    .alert-success {
        background-color: #4CAF50;
        border: 1px solid #388E3C;
    }
    .alert-error {
        background-color: #f44336;
        border: 1px solid #d32f2f;
    }
    form {
        max-width: 600px;
        margin: 0 auto;
        padding: 20px;
        border: 1px solid #ccc;
        border-radius: 8px;
        background-color: #f9f9f9;
    }
    form label {
        display: block;
        margin-bottom: 5px;
        font-weight: bold;
    }
    form input[type="text"] {
        width: 100%;
        padding: 8px;
        margin-bottom: 15px;
        border: 1px solid #ddd;
        border-radius: 4px;
        box-sizing: border-box;
    }
    form input[type="submit"] {
        background-color: #4CAF50;
        color: white;
        border: none;
        padding: 10px 20px;
        font-size: 16px;
        border-radius: 4px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }
    form input[type="submit"]:hover {
        background-color: #45a049;
    }
    .button-container {
        display: flex;
        gap: 10px;
    }
    .btn {
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
        color: #fff;
        transition: background-color 0.3s, transform 0.3s;
    }
    .edit {
        background-color: #4CAF50;
    }
    .edit:hover {
        background-color: #45a049;
        transform: scale(1.05);
    }
    .view {
        background-color: #2196F3;
    }
    .view:hover {
        background-color: #0b7dda;
        transform: scale(1.05);
    }
    .delete {
        background-color: #f44336;
    }
    .delete:hover {
        background-color: #e53935;
        transform: scale(1.05);
    }
    .btn:active {
        transform: scale(0.98);
    }
</style>

<?php

class ListarProduto {

    public function cadastrarProduto() {
        ?>
        <form action="controler/indexProduto.php" method="POST">
        
        <label for="IDProduto">IDProduto</label>
            <input type="text" name="IDProduto" id="IDProduto"><br><br>
        
        <label for="Produto">Produto</label>
            <input type="text" name="Produto" id="Produto"><br><br>

            <label for="IDCategoria">ID Categoria</label>
            <input type="text" name="IDCategoria" id="IDCategoria"><br><br>

            <label for="IDSegmento">ID Segmento</label>
            <input type="text" name="IDSegmento" id="IDSegmento"><br><br>

            <label for="ImagemProduto">Imagem do Produto</label>
            <input type="text" name="ImagemProduto" id="ImagemProduto"><br><br>

            <label for="Marca">Marca (URL da Imagem)</label>
            <input type="text" name="Marca" id="Marca"><br><br>

            <label for="Preco">Preço</label>
            <input type="text" name="Preco" id="Preco"><br><br>

            <input type="hidden" name="opcao" value="inserir">
            <input type="submit" value="CADASTRAR">
        </form>
        <?php
    }

    public function alterarProduto($produto) {
        ?>
        <form action="controler/indexProduto.php" method="POST">
            <label for="Produto">Produto</label>
            <input type="text" name="Produto" id="Produto" value="<?=$produto[0]["Produto"];?>"><br><br>

            <label for="IDCategoria">ID Categoria</label>
            <input type="text" name="IDCategoria" id="IDCategoria" value="<?=$produto[0]["IDCategoria"];?>"><br><br>

            <label for="IDSegmento">ID Segmento</label>
            <input type="text" name="IDSegmento" id="IDSegmento" value="<?=$produto[0]["IDSegmento"];?>"><br><br>

            <label for="ImagemProduto">Imagem do Produto</label>
            <input type="text" name="ImagemProduto" id="ImagemProduto" value="<?=$produto[0]["ImagemProduto"];?>"><br><br>

            <label for="Marca">Marca (URL da Imagem)</label>
            <input type="text" name="Marca" id="Marca" value="<?=$produto[0]["Marca"];?>"><br><br>

            <label for="Preco">Preço</label>
            <input type="text" name="Preco" id="Preco" value="<?=$produto[0]["Preco"];?>"><br><br>

            <input type="hidden" name="opcao" value="alterar">
            <input type="submit" value="ATUALIZAR">
        </form>
        <?php
    }

    public function ListarTodos($produtos) {
        if (isset($_GET["acao"]) && !empty($_GET["acao"]) && isset($_GET["mensagem"]) && !empty($_GET["mensagem"])) {
            $acao = $_GET["acao"];
            $mensagem = $_GET["mensagem"];

            if ($acao == "excluir" && $mensagem == "sucesso") {
                echo '<div class="alert alert-success"><strong>Sucesso!</strong> Registro excluído com sucesso.</div>';
            } elseif ($acao == "excluir" && $mensagem == "erro") {
                echo '<div class="alert alert-error"><strong>Erro!</strong> Erro ao excluir o registro.</div>';
            } elseif ($acao == "editar" && $mensagem == "sucesso") {
                echo '<div class="alert alert-success"><strong>Sucesso!</strong> Registro atualizado com sucesso.</div>';
            } elseif ($acao == "editar" && $mensagem == "erro") {
                echo '<div class="alert alert-error"><strong>Erro!</strong> Erro ao atualizar o registro.</div>';
            } elseif ($acao == "inserir" && $mensagem == "sucesso") {
                echo '<div class="alert alert-success"><strong>Sucesso!</strong> Registro inserido com sucesso.</div>';
            } elseif ($acao == "inserir" && $mensagem == "erro") {
                echo '<div class="alert alert-error"><strong>Erro!</strong> Erro ao inserir o registro.</div>';
            }
        }
        ?>
        <a href="index.php?pagina=Produto&opcao=inserir">
            <button class="btn-cadastrar">Cadastrar</button>
        </a><br>

        <table>
            <thead>
                <tr>
                    <th>ID Produto</th>
                    <th>Produto</th>
                    <th>ID Categoria</th>
                    <th>ID Segmento</th>
                    <th>Imagem do Produto</th>
                    <th>Marca</th>
                    <th>Preço</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($produtos as $produto) { ?>
                <tr>
                    <td><?= $produto['IDProduto'] ?></td>
                    <td><?= $produto['Produto'] ?></td>
                    <td><?= $produto['IDCategoria'] ?></td>
                    <td><?= $produto['IDSegmento'] ?></td>
                    <td><img src="<?= $produto['ImagemProduto'] ?>" alt="Imagem do Produto" style="width:100px; height:auto;"></td>
                    <td><img src="<?= $produto['Marca'] ?>" alt="Imagem da Marca" style="width:100px; height:auto;"></td>
                    <td><?= $produto['Preco'] ?></td>
                    <td>
                        <div class="button-container">
                            <a href="index.php?pagina=Produto&opcao=visualizar&IDProduto=<?=$produto['IDProduto'];?>"><button class="btn view">Ver</button></a>
                            <a href="index.php?pagina=Produto&opcao=editar&IDProduto=<?=$produto['IDProduto'];?>"><button class="btn edit">Editar</button></a>
                            <a href="index.php?pagina=Produto&opcao=excluir&IDProduto=<?=$produto['IDProduto'];?>"><button class="btn delete">Excluir</button></a>
                        </div>
                    </td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
        <?php
    }
}
