<h1 align="center"> Aulas de Tecnologia para Internet </h1>

<p>Este repositório contém um projeto construído com os alunos do curso de Análise e Desenvolvimento de Sistemas na disciplina de  Tecnologia para Internet.</p>

![Badge em Desenvolvimento](http://img.shields.io/static/v1?label=STATUS&message=EM%20DESENVOLVIMENTO&color=GREEN&style=for-the-badge)
 ![Java]( https://img.shields.io/badge/php-000?style=for-the-badge&logo=java )
![GitHub Org's stars](https://img.shields.io/github/stars/rafaelflorindo?style=social)


# :hammer: Funcionalidades

- `PHP OO`: Introdução a Linguagem PHP OO, operadores, classes, objetos e atributos
- `PHP PDO`: SGDB - Mysql - CRUD
- `PHP PDO`: SGDB - SQLServer - CRUD

- Tecnologia
<img loading="lazy" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/php/php-original.svg" width="40" height="40"/> 


<div>
<a href="https://github.com/rafaelflorindo">
<img loading="lazy" height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=rafaelflorindo&layout=compact&langs_count=7&theme=dracula"/>
<img loading="lazy" height="180em" src="https://github-readme-stats.vercel.app/api?username=rafaelflorindo&show_icons=true&theme=dracula&include_all_commits=true&count_private=true"/>
</div>

 

